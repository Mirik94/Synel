package TestCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import Utils.AllBrowsers;

public class BaseForTests {

	AllBrowsers allbrowser;
	static WebDriver driver;

	//Reusable test is created to pull data from browsers class
	@Parameters({ "browser", "url" })
	@BeforeTest
	public void beforetest(String browser, String url) {
		allbrowser = new AllBrowsers();
		allbrowser.SetUpBrowsers(browser, url);
		driver = allbrowser.getDriver();

	}

	//quiting browsers after test cases are accomplited
	@AfterTest
	public void aftertest() {
		//allbrowser.closeTab();

	}

}
