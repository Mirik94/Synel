package TestCases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import PageObjectModel.SignInAndPost;

public class syneltest_1 extends BaseForTests {
	
	//To Log In with credentials
	@Parameters({ "username", "password" })
	@Test
	public void logInPage(String username, String password) {

		SignInAndPost login = new SignInAndPost(driver);
		login.signinWithCredentials(username, password);
	}
}
