package TestCases;

import org.testng.annotations.Test;

import PageObjectModel.SignInAndPost;

public class syneltest_2 extends BaseForTests {

	// To publish a Text
	@Test
	public void postNewEntry() {

		SignInAndPost login = new SignInAndPost(driver);
		login.postNewEntry();
	}
}
