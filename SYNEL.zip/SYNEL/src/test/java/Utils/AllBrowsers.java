package Utils;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AllBrowsers {

	private WebDriver driver;

	public void SetUpBrowsers(String browser, String url) {

		if (browser.matches("chrome")) {
			String DriversPath = "C:\\Users\\v-mirsha.EUROPE\\eclipse-workspace\\TestNG_Tutorials\\drivers\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", DriversPath);
			driver = new ChromeDriver();
		} else if (browser.matches("edge")) {
			String DriversPath = "C:\\Users\\v-mirsha.EUROPE\\eclipse-workspace\\TestNG_Tutorials\\drivers\\msedgedriver.exe";
			System.setProperty("webdriver.edge.driver", DriversPath);
			driver = new EdgeDriver();
		} else if (browser.matches("firefox")) {
			String DriversPath = "C:\\Users\\v-mirsha.EUROPE\\eclipse-workspace\\TestNG_Tutorials\\drivers\\drivers\\";
			System.setProperty("webdriver.firefox.driver", DriversPath);
			driver = new FirefoxDriver();
		} else {
			System.out.println("Please choose valid Browser");
			System.exit(0);
		}

		// to maximize the sire window
		driver.manage().window().maximize();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		// pageload timeout==> used in POM
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));

		// scriptload timeout
		driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(10));

		if (url != "") {
			driver.get(url);

		} else {
			System.out.println("");
			driver.get("about:blank");
		}

	}

	// return the instance of a driver
	public WebDriver getDriver() {
		return this.driver;

	}

	public void closeTab() {
		driver.close();
	}

	public void quitBrowser() {
		driver.quit();
	}

}
