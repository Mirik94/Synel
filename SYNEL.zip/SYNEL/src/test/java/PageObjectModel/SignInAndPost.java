package PageObjectModel;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

public class SignInAndPost { // Model + design pattern // application based reusability test // POM

	private WebDriver driver;

	// finding login in button
	@CacheLookup
	@FindBy(xpath = "//a[contains(text(),'Log in')]")
	WebElement login;

	// finding usernameinbox
	@CacheLookup
	@FindBy(id = "user")
	WebElement signUsername;

	// finding passwordinbox
	@CacheLookup
	@FindBy(name = "password")
	WebElement pwd;

	// finding Login button
	@CacheLookup
	@FindBy(name = "action:login")
	WebElement loginbtn;

	// postinginbtn
	@CacheLookup
	@FindBy(xpath = "//header/div[1]/nav[2]/ul[1]/li[4]/a[1]")
	WebElement publbtn;

	// draftwindow
	@CacheLookup
	@FindBy(xpath = "//button[@class='close-0-2-209']")
	WebElement draft;

	// randomText
	@CacheLookup
	@FindBy(xpath = "//div[@class='public-DraftStyleDefault-block public-DraftStyleDefault-ltr']")
	WebElement Text;

	// title
	@CacheLookup
	@FindBy(xpath = "//textarea")
	WebElement title;

	// Publishing
	@CacheLookup
	@FindBy(xpath = "//span[text()='Tune in and publish']")
	WebElement publishbtn;

	// Publishing2
	@CacheLookup
	@FindBy(xpath = "//span[@class='rootIn-0-2-98' and text()='Publish']")
	WebElement publish2btn;

	// this to call current instance which is SignInAndPost
	public SignInAndPost(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void signinWithCredentials(String username, String password) {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// click on Log in button on home page
		wait.until(ExpectedConditions.elementToBeClickable(login)).click();

		// Sending info to username box
		signUsername.sendKeys(username);

		// Sending info to password box
		pwd.sendKeys(password);

		// printing user name untered
		Reporter.log("User name entered: " + username);
		Reporter.log("Password entered: " + password);

		// click on Log In button after validUserValidPassword entered
		wait.until(ExpectedConditions.elementToBeClickable(loginbtn)).click();

	}

	public void postNewEntry() {

		Actions act = new Actions(driver);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		wait.until(ExpectedConditions.elementToBeClickable(publbtn)).click();

		// closing draft rec window
		draft.click();

		// printing title
		title.sendKeys("Sharafov Mirgolib");

		// moving mouse to text inbox
		act.moveToElement(Text).click().build().perform();

		// printing text in inbox
		Text.sendKeys("Hello SYNEL");

		// publishing by clicking on publish button
		wait.until(ExpectedConditions.elementToBeClickable(publishbtn)).click();

		// publishing by clicking on publish button with no changes
		wait.until(ExpectedConditions.elementToBeClickable(publish2btn)).click();

	}

}
